package com.ust.hibmain.hibcontroller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ust.hibmain.hibservice.HibService;
import com.ust.hibmain.model.Employee;

@RestController
//@Controller
public class HibController {

	@Autowired
	HibService hibservice;

	// Add employee using the URL
	@RequestMapping("add/{name}/{age}/{place}")
	@GetMapping
	public String addEmployee(@PathVariable String name, @PathVariable int age, @PathVariable String place) {
		Employee employee = new Employee(name, age, place);
		hibservice.addEmp(employee);

		System.out.println(employee.getId());
		System.out.println(employee.getName());
		System.out.println(employee.getAge());
		System.out.println(employee.getPlace());

		return " Add-Successfully ";
	}

	// ---------------Receive the file input from console and print on the
	// browser--------

	@RequestMapping("/file")
	public String Readingfile() throws IOException {

		// try {
		// FileWriter writer = new FileWriter("MyFile.txt", true);
		// writer.write("Hello World");
		// writer.write("\r\n"); // write new line
		// writer.write("Good Bye!");
		// writer.close();
		// } catch (IOException e) {
		// e.printStackTrace();
		// }

		String fname;
		String content = "";
		Scanner scan = new Scanner(System.in);

		// System.out.println("Enter the file name to create(including the .txt
		// format)");
		// String fileName=scan.nextLine();
		// FileWriter writer = new FileWriter(fileName, true);
		// System.out.println("Enter the content to file:");
		// String fileContent=scan.next();
		// System.out.println(fileContent);
		// writer.write(fileContent);
		// writer.close();
		/* enter filename with extension to open and read its content */

		System.out.print("Enter File Name to Open (with extension like file.txt) : ");
		fname = scan.nextLine();

		/* this will reference only one line at a time */

		String line = null;
		try {
			/* FileReader reads text files in the default encoding */
			FileReader fileReader = new FileReader(fname);

			/* always wrap the FileReader in BufferedReader */
			BufferedReader bufferedReader = new BufferedReader(fileReader);

			while ((line = bufferedReader.readLine()) != null) {
				content += line;
				System.out.println(line);
			}

			/* always close the file after use */
			bufferedReader.close();
			scan.close();
		} catch (IOException ex) {
			System.out.println("Error reading file named '" + fname + "'");
		}
		return content;
	}
	
	// ------------------------------

	// -----------------------------Add employee Using the
	// Form------------------------------

	@GetMapping("/")
	public String index() {
		return "redirect:/formdata";
	}

	@RequestMapping("/formdata")
	@GetMapping
	public String dataForm() {
		return "ef";
	}

	@RequestMapping("empform")
	@PostMapping
	public String datareturn(Employee employee, Model model) {
		hibservice.addEmp(employee);
		model.addAttribute("employee", employee);
		return "ss";
	}

	@RequestMapping("del")
	@PostMapping
	public String deleteing() {
		return "dl";
	}

	@RequestMapping("delete1")
	@PostMapping
	public String deleteEmpp(int id) {
		hibservice.deleteEmployee(id);
		return "ds";
	}

	@RequestMapping("sea")
	@PostMapping
	public String searching() {
		return "es";
	}

	@RequestMapping("search1")
	@PostMapping
	public String searchEmployee(int id, Model model) {

		Employee employee = hibservice.serchEmployee(id);
		model.addAttribute("emp", employee);
		return "ess";

	}

	@RequestMapping("display")
	@PostMapping
	public String alldisplay(Model model) {
		List<Employee> list = hibservice.getAllEmp();
		model.addAttribute("emp", list);
		return "da";
	}
	
	@RequestMapping("up")
	@PostMapping
	public String updating() {
		return "up";
	}
	
	@RequestMapping("update1")
	@PostMapping
	public String updateEmployee(Employee employee)

	{
		hibservice.updateEmployee(employee);
		return "ups";
	}
	// --------------------------------------------------------------
	// Add employee using body
	
	@RequestMapping("Add")
	@PostMapping

	public String addEmp(@RequestBody Employee employee) {
		hibservice.addEmp(employee);
		System.out.println(employee.getId());
		System.out.println(employee.getName());
		System.out.println(employee.getAge());
		System.out.println(employee.getPlace());
		return "Successfully added";
	}

	// List all employees
	@RequestMapping("all")
	@GetMapping
	public List<Employee> getallEmployee() {
		return hibservice.getAllEmp();
	}

	// Search a particular employee using id
	@RequestMapping("search")
	@PostMapping
	public Employee searchEmp(@RequestBody int id) {

		return hibservice.serchEmployee(id);

	}

	// Delete a employee using id
	@RequestMapping("delete")
	@PostMapping
	public String deleteEmp(@RequestBody int id) {

		return hibservice.deleteEmployee(id);
	}

	// Update the employee using id
	@RequestMapping("update")
	@PostMapping
	public String updateEmp(@RequestBody Employee employee)

	{
		hibservice.updateEmployee(employee);
		return "Updated successfully";
	}
}
