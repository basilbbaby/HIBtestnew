package com.ust.hibmain.hibdao;

import java.util.List;

import com.ust.hibmain.model.Employee;

public interface HibDao {

	public void addEmployee(Employee employee);

	public List<Employee> allemp();

	public Employee searchEmp(int id);

	public String deleteEmployee(int id);

	public void updateEmp(Employee employee);
}
