package com.ust.hibmain.hibdao;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.ust.hibmain.model.Employee;

@Repository
public class HibDaoImpl implements HibDao {

	@Autowired
	private SessionFactory SessionFactory;

	public SessionFactory getSessionFactory() {
		return SessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		SessionFactory = sessionFactory;
	}

	@Override
	public void addEmployee(Employee employee) {

		Session session = SessionFactory.openSession();
		session.beginTransaction();
		session.save(employee);
		session.getTransaction().commit();
	}

	@Override
	public List<Employee> allemp() {

		Session session = SessionFactory.openSession();
		Query query = session.createQuery("from Employee");
		@SuppressWarnings("unchecked")
		List<Employee> employees = query.list();
		return employees;

	}

	@Override
	public Employee searchEmp(int id) {

		Session session = SessionFactory.openSession();
		Query query = session.createQuery("from Employee where id=" + id);
		Employee emp = (Employee) query.uniqueResult();
		return emp;
	}

	@Override
	public String deleteEmployee(int id) {
		Session session = SessionFactory.openSession();
		session.beginTransaction();
		Employee emp = session.get(Employee.class, id);
		session.delete(emp);
		session.getTransaction().commit();
		return "deleted successfully!";
	}

	@Override
	public void updateEmp(Employee employee) {

		if (employee.getName() != null) {
			Session session = SessionFactory.openSession();
			session.beginTransaction();
			int Eid = employee.getId();
			Employee emp = session.get(Employee.class, Eid);
			emp.setName(employee.getName());
			session.update(emp);
			session.getTransaction().commit();
		} else if (employee.getPlace() != null) {
			Session session = SessionFactory.openSession();
			session.beginTransaction();
			int Eid = employee.getId();
			Employee emp = session.get(Employee.class, Eid);
			emp.setPlace(employee.getPlace());
			session.update(emp);
			session.getTransaction().commit();

		} else {
			Session session = SessionFactory.openSession();
			session.beginTransaction();
			int Eid = employee.getId();
			Employee emp = session.get(Employee.class, Eid);
			emp.setAge(employee.getAge());
			session.update(emp);
			session.getTransaction().commit();
		}

		// Session session = SessionFactory.openSession();
		// session.beginTransaction();
		// int Eid = employee.getId();
		// Employee emp = session.get(Employee.class, Eid);
		// emp.setName(employee.getName());
		// emp.setAge(employee.getAge());
		// emp.setPlace(employee.getPlace());
		// session.update(emp);
		// session.getTransaction().commit();
	}

}
