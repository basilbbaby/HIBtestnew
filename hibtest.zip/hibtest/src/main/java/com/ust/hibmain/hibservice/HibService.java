package com.ust.hibmain.hibservice;

import java.util.List;

import com.ust.hibmain.model.Employee;

public interface HibService {
	
	public void addEmp(Employee employee);

	public List<Employee> getAllEmp();

	public Employee serchEmployee(int id);

	public String deleteEmployee(int id);

	public void updateEmployee(Employee employee);

}
