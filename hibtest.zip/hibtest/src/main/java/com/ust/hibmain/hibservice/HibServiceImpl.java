package com.ust.hibmain.hibservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.hibmain.hibdao.HibDao;
import com.ust.hibmain.model.Employee;

@Service
public class HibServiceImpl implements HibService {

	@Autowired
	HibDao hibdao;

	@Override
	public void addEmp(Employee employee) {
		hibdao.addEmployee(employee);

	}

	@Override
	public List<Employee> getAllEmp() {

		return hibdao.allemp();

	}

	@Override
	public Employee serchEmployee(int id) {
		return hibdao.searchEmp(id);
	}

	@Override
	public String deleteEmployee(int id) {

		return hibdao.deleteEmployee(id);
	}

	@Override
	public void updateEmployee(Employee employee) {
		hibdao.updateEmp(employee);

	}

}
