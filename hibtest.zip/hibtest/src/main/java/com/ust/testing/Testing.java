package com.ust.testing;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Testing {

	@RequestMapping("/hello")
	public ModelAndView helloWorld() {

		FileReader freader = null;
		String print = " ";

		try {

			freader = new FileReader("C:/Users/AF78078/Desktop/Data.txt");

		} catch (FileNotFoundException e) {

			e.printStackTrace();

		}

		BufferedReader br = new BufferedReader(freader);
		String s;
		try {

			while ((s = br.readLine()) != null) {
				print += s;
				System.out.println(s);

			}

		} catch (IOException e) {
			e.printStackTrace();

		}

		try {

			freader.close();

		} catch (IOException e) {

			e.printStackTrace();

		}
		return new ModelAndView("hellopage", "s", print);
	}
}
